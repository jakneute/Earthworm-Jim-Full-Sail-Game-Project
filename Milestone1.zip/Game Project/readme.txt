The controls so far.

Left and right - move left and right.
Left Control + any direction - fire in that direction

P - Pause Game
F2 - increase rate of fire (somewhat buggy)
F3 - increase bullet size (very buggy)
F4 - super speed
F5 - god mode(won't do anything)


events: move left
	move right
	shoot left
	shoot right
	shoot up
	shoot down
	shoot up-left
	shoot up-right
	shoot down-left
	shoot down-right

messages: 	collision
		destruction
		one for activating each cheat
		